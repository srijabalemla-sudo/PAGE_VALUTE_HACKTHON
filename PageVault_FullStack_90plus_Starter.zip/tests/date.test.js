import test from 'node:test';
import assert from 'node:assert/strict';
export function dueDateFrom(start,days=14){const d=new Date(start);d.setDate(d.getDate()+days);return d;}
export function isOverdue(due,now=new Date()){return new Date(due).getTime()<now.getTime();}
test('standard loan period is fourteen days',()=>{assert.equal(dueDateFrom('2026-11-20T09:00:00Z').toISOString(),'2026-12-04T09:00:00.000Z')});
test('a due date in the past is overdue',()=>{assert.equal(isOverdue('2026-11-19T09:00:00Z',new Date('2026-11-20T09:00:00Z')),true)});
test('a future due date is not overdue',()=>{assert.equal(isOverdue('2026-11-21T09:00:00Z',new Date('2026-11-20T09:00:00Z')),false)});
