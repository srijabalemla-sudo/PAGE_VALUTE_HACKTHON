# PageVault — OpenShelf Challenge

Full-stack campus peer-to-peer textbook exchange built with React, React Router, CSS, Node.js, Express and SQLite.

## Features
- Register/login with bcrypt password hashing and server-side sessions.
- Search by book title, author, course code and department; filter by availability.
- Seed database with 30 textbooks.
- Create listings, request books, approve/decline requests, and mark loans returned.
- Atomic availability update inside a SQLite transaction prevents two approvals for the same copy.
- 14-day due dates, hourly server-side due-soon/overdue notification generation, notification inbox.
- Browser notification permission control, dashboard, validation, rate limiting and security headers.
- Unit tests for due-date and overdue calculations.

## Requirements
Node.js 18+ and npm.

## Setup
1. Extract the ZIP and open the project folder in VS Code.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set a long random `SESSION_SECRET`.
4. Run `npm run dev`.
5. Open `http://localhost:5173`.

API runs on `http://localhost:4000`. SQLite database is created automatically at `server/data/pagevault.sqlite`.

## Demo account
- Email: `demo@pagevault.edu`
- Password: `DemoPass123!`

Create a separate account to test borrowing between users. The demo user owns the seeded catalogue.

## Tests and production build
- `npm test`
- `npm run build`
- `npm start` (set `NODE_ENV=production`; frontend build is served by Express)

## Important notes
- Due reminders are created by a server cron job once per hour. The server must remain running for scheduled jobs to execute.
- Browser notifications require HTTPS in deployment (localhost is allowed) and explicit permission. The notification inbox remains available in the app.
- For a public deployment, configure a strong `SESSION_SECRET`, HTTPS, secure cookies, backups, and a production database volume.
- The automated tests included here cover date calculations. Add API integration/E2E tests (for example with Supertest and Playwright) before production release and document the test run in your submission.
