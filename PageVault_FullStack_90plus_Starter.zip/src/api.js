const api=async(url,options={})=>{
 const res=await fetch(`/api${url}`,{credentials:'include',headers:{'Content-Type':'application/json',...(options.headers||{})},...options});
 const data=await res.json().catch(()=>({}));
 if(!res.ok)throw new Error(data.error||'Request failed');return data;
};
export default api;
