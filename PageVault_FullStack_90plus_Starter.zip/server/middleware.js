export function requireAuth(req,res,next) {
 if(!req.session.user) return res.status(401).json({error:'Please sign in to continue.'});
 next();
}
export function asyncRoute(fn) { return (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next); }
