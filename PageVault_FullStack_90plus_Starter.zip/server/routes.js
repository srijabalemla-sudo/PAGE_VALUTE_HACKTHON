import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { db } from './db.js';
import { registerSchema,loginSchema,bookSchema,parse } from './validation.js';
import { requireAuth,asyncRoute } from './middleware.js';
const router=Router();
const publicUser=u=>({id:u.id,name:u.name,email:u.email,department:u.department});
const notify=(uid,message,type='info')=>db.prepare('INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)').run(uid,message,type);

router.post('/auth/register',asyncRoute(async(req,res)=>{
 const data=parse(registerSchema,req.body);
 const exists=db.prepare('SELECT id FROM users WHERE email=?').get(data.email);
 if(exists) return res.status(409).json({error:'An account with this email already exists.'});
 const hash=await bcrypt.hash(data.password,12);
 const result=db.prepare('INSERT INTO users(name,email,password_hash,department) VALUES(?,?,?,?)').run(data.name,data.email,hash,data.department);
 const user=publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(result.lastInsertRowid));
 req.session.user=user; res.status(201).json({user});
}));
router.post('/auth/login',asyncRoute(async(req,res)=>{
 const d=parse(loginSchema,req.body), user=db.prepare('SELECT * FROM users WHERE email=?').get(d.email);
 if(!user || !(await bcrypt.compare(d.password,user.password_hash))) return res.status(401).json({error:'Invalid email or password.'});
 req.session.user=publicUser(user); res.json({user:req.session.user});
}));
router.post('/auth/logout',(req,res)=>req.session.destroy(()=>{res.clearCookie('connect.sid');res.json({ok:true});}));
router.get('/auth/me',(req,res)=>res.json({user:req.session.user||null}));

router.get('/books',asyncRoute(async(req,res)=>{
 const q=String(req.query.q||'').trim().slice(0,100), dept=String(req.query.department||'').slice(0,80);
 const status=String(req.query.status||'');
 let sql=`SELECT b.*,u.name owner_name FROM books b JOIN users u ON u.id=b.owner_id WHERE 1=1`, args=[];
 if(q){sql+=' AND (b.title LIKE ? OR b.author LIKE ? OR b.course LIKE ? OR b.department LIKE ?)';const x=`%${q}%`;args.push(x,x,x,x);}
 if(dept){sql+=' AND b.department=?';args.push(dept);}
 if(status==='available'||status==='borrowed'){sql+=' AND b.status=?';args.push(status);}
 sql+=' ORDER BY b.created_at DESC LIMIT 200';
 res.json({books:db.prepare(sql).all(...args)});
}));
router.post('/books',requireAuth,asyncRoute(async(req,res)=>{
 const b=parse(bookSchema,req.body);
 const r=db.prepare('INSERT INTO books(owner_id,title,author,course,department,condition,description) VALUES(?,?,?,?,?,?,?)').run(req.session.user.id,b.title,b.author,b.course,b.department,b.condition,b.description);
 res.status(201).json({book:db.prepare('SELECT b.*,u.name owner_name FROM books b JOIN users u ON u.id=b.owner_id WHERE b.id=?').get(r.lastInsertRowid)});
}));
router.delete('/books/:id',requireAuth,(req,res)=>{
 const result=db.prepare("DELETE FROM books WHERE id=? AND owner_id=? AND status='available'").run(Number(req.params.id),req.session.user.id);
 if(!result.changes)return res.status(404).json({error:'Book not found, unavailable, or not owned by you.'});
 res.json({ok:true});
});
router.post('/books/:id/request',requireAuth,(req,res)=>{
 const user=req.session.user, book=db.prepare('SELECT * FROM books WHERE id=?').get(Number(req.params.id));
 if(!book)return res.status(404).json({error:'Book not found.'});
 if(book.owner_id===user.id)return res.status(400).json({error:'You cannot request your own book.'});
 if(book.status!=='available')return res.status(409).json({error:'This book is no longer available.'});
 const prior=db.prepare("SELECT id FROM borrow_requests WHERE book_id=? AND borrower_id=? AND status IN ('pending','approved')").get(book.id,user.id);
 if(prior)return res.status(409).json({error:'You already have an active request for this book.'});
 const r=db.prepare('INSERT INTO borrow_requests(book_id,borrower_id,owner_id) VALUES(?,?,?)').run(book.id,user.id,book.owner_id);
 notify(book.owner_id,`${user.name} requested "${book.title}".`,'request');
 res.status(201).json({requestId:r.lastInsertRowid});
});
router.get('/requests',requireAuth,(req,res)=>{
 const id=req.session.user.id;
 const rows=db.prepare(`SELECT r.*,b.title,b.author,b.course,bu.name borrower_name,ou.name owner_name
 FROM borrow_requests r JOIN books b ON b.id=r.book_id JOIN users bu ON bu.id=r.borrower_id JOIN users ou ON ou.id=r.owner_id
 WHERE r.borrower_id=? OR r.owner_id=? ORDER BY r.requested_at DESC`).all(id,id);
 res.json({requests:rows});
});
router.patch('/requests/:id/decision',requireAuth,(req,res)=>{
 const id=Number(req.params.id), status=req.body.status;
 if(!['approved','rejected'].includes(status))return res.status(400).json({error:'Decision must be approved or rejected.'});
 const tx=db.transaction(()=>{
  const r=db.prepare('SELECT * FROM borrow_requests WHERE id=?').get(id);
  if(!r||r.owner_id!==req.session.user.id)throw Object.assign(new Error('Request not found.'),{status:404});
  if(r.status!=='pending')throw Object.assign(new Error('This request has already been processed.'),{status:409});
  if(status==='approved'){
   const update=db.prepare("UPDATE books SET status='borrowed' WHERE id=? AND status='available'").run(r.book_id);
   if(!update.changes)throw Object.assign(new Error('Book is no longer available.'),{status:409});
   const due=new Date();due.setDate(due.getDate()+14);
   db.prepare("UPDATE borrow_requests SET status='approved',due_date=? WHERE id=?").run(due.toISOString(),id);
  }else db.prepare("UPDATE borrow_requests SET status='rejected' WHERE id=?").run(id);
  notify(r.borrower_id,status==='approved'?'Your book request was approved.':'Your book request was declined.',status);
 });
 try{tx();res.json({ok:true});}catch(e){res.status(e.status||400).json({error:e.message});}
});
router.post('/requests/:id/return',requireAuth,(req,res)=>{
 const tx=db.transaction(()=>{
  const r=db.prepare('SELECT * FROM borrow_requests WHERE id=?').get(Number(req.params.id));
  if(!r||r.borrower_id!==req.session.user.id)throw Object.assign(new Error('Request not found.'),{status:404});
  if(r.status!=='approved')throw Object.assign(new Error('Only approved loans can be returned.'),{status:409});
  db.prepare("UPDATE borrow_requests SET status='returned',returned_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);
  db.prepare("UPDATE books SET status='available' WHERE id=?").run(r.book_id);
  notify(r.owner_id,'A borrowed book has been marked as returned.','returned');
 });
 try{tx();res.json({ok:true});}catch(e){res.status(e.status||400).json({error:e.message});}
});
router.get('/notifications',requireAuth,(req,res)=>{
 res.json({notifications:db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.session.user.id)});
});
router.patch('/notifications/read-all',requireAuth,(req,res)=>{
 db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.session.user.id);res.json({ok:true});
});
router.get('/dashboard',requireAuth,(req,res)=>{
 const id=req.session.user.id;
 const counts={
 listed:db.prepare('SELECT COUNT(*) n FROM books WHERE owner_id=?').get(id).n,
 borrowed:db.prepare("SELECT COUNT(*) n FROM borrow_requests WHERE borrower_id=? AND status='approved'").get(id).n,
 pending:db.prepare("SELECT COUNT(*) n FROM borrow_requests WHERE owner_id=? AND status='pending'").get(id).n,
 returned:db.prepare("SELECT COUNT(*) n FROM borrow_requests WHERE borrower_id=? AND status='returned'").get(id).n
 };
 const due=db.prepare(`SELECT r.id,r.due_date,b.title FROM borrow_requests r JOIN books b ON b.id=r.book_id WHERE r.borrower_id=? AND r.status='approved' AND r.due_date IS NOT NULL ORDER BY r.due_date`).all(id);
 res.json({counts,due});
});
export default router;
