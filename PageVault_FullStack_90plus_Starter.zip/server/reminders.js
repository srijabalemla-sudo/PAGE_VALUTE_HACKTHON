import cron from 'node-cron';
import { db } from './db.js';
export function startReminderJob(){
 // Runs hourly. Each reminder is inserted once per loan and reminder type.
 db.exec(`CREATE TABLE IF NOT EXISTS reminder_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL, kind TEXT NOT NULL,
  UNIQUE(request_id,kind))`);
 cron.schedule('0 * * * *',()=>{
  const rows=db.prepare(`SELECT r.id,r.borrower_id,r.due_date,b.title FROM borrow_requests r
   JOIN books b ON b.id=r.book_id WHERE r.status='approved' AND r.due_date IS NOT NULL`).all();
  const insert=db.prepare('INSERT OR IGNORE INTO reminder_log(request_id,kind) VALUES(?,?)');
  const add=db.prepare('INSERT INTO notifications(user_id,message,type) VALUES(?,?,?)');
  const now=Date.now();
  const tx=db.transaction(()=>rows.forEach(r=>{
   const diff=new Date(r.due_date).getTime()-now, day=86400000;
   if(diff<=day && diff>0 && insert.run(r.id,'due-soon').changes)add.run(r.borrower_id,`"${r.title}" is due within 24 hours.`,'reminder');
   if(diff<=0 && insert.run(r.id,'overdue').changes)add.run(r.borrower_id,`"${r.title}" is overdue. Please return it.`,'overdue');
  }));
  tx();
 });
}
