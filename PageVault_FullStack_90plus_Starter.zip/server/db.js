import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import fs from 'node:fs';
import path from 'node:path';
const dataDir = path.join(process.cwd(), 'server', 'data');
fs.mkdirSync(dataDir, {recursive:true});
export const db = new Database(path.join(dataDir, 'pagevault.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL,
 department TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS books (
 id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL REFERENCES users(id),
 title TEXT NOT NULL, author TEXT NOT NULL, course TEXT NOT NULL,
 department TEXT NOT NULL, condition TEXT NOT NULL, description TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available','borrowed')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS borrow_requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL REFERENCES books(id),
 borrower_id INTEGER NOT NULL REFERENCES users(id), owner_id INTEGER NOT NULL REFERENCES users(id),
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','returned')),
 requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, due_date TEXT,
 returned_at TEXT
);
CREATE TABLE IF NOT EXISTS notifications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
 message TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'info', read INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reviews (
 id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_id INTEGER NOT NULL REFERENCES borrow_requests(id),
 reviewer_id INTEGER NOT NULL REFERENCES users(id), rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
 comment TEXT DEFAULT '', UNIQUE(transaction_id, reviewer_id)
);
CREATE INDEX IF NOT EXISTS idx_books_search ON books(title, course, department);
CREATE INDEX IF NOT EXISTS idx_requests_borrower ON borrow_requests(borrower_id, status);
CREATE INDEX IF NOT EXISTS idx_requests_owner ON borrow_requests(owner_id, status);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read);
`);
const count = db.prepare('SELECT COUNT(*) n FROM books').get().n;
if (count === 0) {
 const seedUser = db.prepare('INSERT OR IGNORE INTO users(name,email,password_hash,department) VALUES(?,?,?,?)');
 const demoHash = bcrypt.hashSync('DemoPass123!', 10);
 seedUser.run('OpenShelf Demo','demo@pagevault.edu',demoHash,'Computer Science');
 const owner = db.prepare('SELECT id FROM users WHERE email=?').get('demo@pagevault.edu').id;
 const rows = [
 ['Introduction to Algorithms','Thomas H. Cormen','CS301','Computer Science','Good'],
 ['Clean Code','Robert C. Martin','CS302','Computer Science','Like New'],
 ['Operating System Concepts','Silberschatz','CS303','Computer Science','Good'],
 ['Database System Concepts','Silberschatz','CS304','Computer Science','Fair'],
 ['Computer Networks','Andrew Tanenbaum','CS305','Computer Science','Good'],
 ['Artificial Intelligence: A Modern Approach','Russell & Norvig','AI401','AIML','Like New'],
 ['Deep Learning','Ian Goodfellow','AI402','AIML','Good'],
 ['Pattern Recognition','Christopher Bishop','AI403','AIML','Fair'],
 ['Python Crash Course','Eric Matthes','CS201','Computer Science','Like New'],
 ['Java: The Complete Reference','Herbert Schildt','CS202','Computer Science','Good'],
 ['The C Programming Language','Kernighan & Ritchie','CS101','Computer Science','Good'],
 ['Discrete Mathematics','Kenneth Rosen','MA201','Mathematics','Fair'],
 ['Engineering Mathematics I','B. S. Grewal','MA101','Mathematics','Good'],
 ['Engineering Physics','H. K. Malik','PH101','Physics','Good'],
 ['Basic Electrical Engineering','D. P. Kothari','EE101','Electrical','Like New'],
 ['Digital Logic Design','M. Morris Mano','EC201','Electronics','Good'],
 ['Signals and Systems','Oppenheim','EC301','Electronics','Fair'],
 ['Data Structures Using C','Reema Thareja','CS203','Computer Science','Good'],
 ['Web Technologies','Uttam K. Roy','CS306','Computer Science','Like New'],
 ['Computer Organization','Carl Hamacher','CS204','Computer Science','Good'],
 ['Software Engineering','Ian Sommerville','CS307','Computer Science','Fair'],
 ['Machine Learning','Tom Mitchell','AI404','AIML','Good'],
 ['Cloud Computing','Rajkumar Buyya','CS405','Computer Science','Like New'],
 ['Cyber Security Essentials','Charles Brooks','CS406','Computer Science','Good'],
 ['Engineering Chemistry','Jain & Jain','CH101','Chemistry','Fair'],
 ['Probability and Statistics','S. C. Gupta','MA301','Mathematics','Good'],
 ['Microprocessors',' Ramesh Gaonkar','EC202','Electronics','Good'],
 ['Data Mining','Jiawei Han','AI405','AIML','Like New'],
 ['Linear Algebra','Gilbert Strang','MA202','Mathematics','Good'],
 ['Design Patterns','Erich Gamma','CS308','Computer Science','Fair']
 ];
 const ins = db.prepare('INSERT INTO books(owner_id,title,author,course,department,condition,description) VALUES(?,?,?,?,?,?,?)');
 const tx = db.transaction(items => items.forEach((b,i)=>ins.run(owner,...b,`Campus exchange copy #${i+1}. Contact the owner to arrange pickup.`)));
 tx(rows);
}
