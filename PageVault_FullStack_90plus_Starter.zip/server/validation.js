import { z } from 'zod';
export const registerSchema = z.object({
 name:z.string().trim().min(2).max(60), email:z.string().trim().email().max(120),
 password:z.string().min(8).max(72).regex(/[A-Z]/,'Add an uppercase letter').regex(/[0-9]/,'Add a number'),
 department:z.string().trim().max(80).optional().default('')
});
export const loginSchema = z.object({email:z.string().trim().email(),password:z.string().min(1).max(72)});
export const bookSchema = z.object({
 title:z.string().trim().min(2).max(140), author:z.string().trim().min(2).max(100),
 course:z.string().trim().min(2).max(30), department:z.string().trim().min(2).max(80),
 condition:z.enum(['Like New','Good','Fair']), description:z.string().trim().max(600).optional().default('')
});
export function parse(schema, data) {
 const result=schema.safeParse(data);
 if(!result.success) { const e=new Error(result.error.issues.map(x=>x.message).join('. ')); e.status=400; throw e; }
 return result.data;
}
