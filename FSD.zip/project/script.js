
let books = [
    {
        id: 1,
        title: "Operating System Concepts",
        author: "Abraham Silberschatz",
        edition: "10th",
        course: "CS301",
        department: "Computer Science",
        condition: "Good",
        owner: "Aarav",
        status: "Available"
    },
    {
        id: 2,
        title: "Computer Networks",
        author: "Andrew Tanenbaum",
        edition: "5th",
        course: "CS302",
        department: "Computer Science",
        condition: "Like New",
        owner: "Priya",
        status: "Available"
    },
    {
        id: 3,
        title: "Digital Design",
        author: "M. Morris Mano",
        edition: "6th",
        course: "EC201",
        department: "Electronics",
        condition: "Good",
        owner: "Rahul",
        status: "Available"
    },
    {
        id: 4,
        title: "Engineering Mathematics",
        author: "B. S. Grewal",
        edition: "1st",
        course: "MA201",
        department: "Mathematics",
        condition: "Good",
        owner: "Ananya",
        status: "Available"
    },
    {
        id: 5,
        title: "Thermodynamics",
        author: "Yunus Cengel",
        edition: "9th",
        course: "ME302",
        department: "Mechanical",
        condition: "Fair",
        owner: "Rohan",
        status: "Available"
    },
    {
        id: 6,
        title: "Signals and Systems",
        author: "Alan Oppenheim",
        edition: "2nd",
        course: "EC303",
        department: "Electronics",
        condition: "Good",
        owner: "Sneha",
        status: "Available"
    }
];

let requests = [];
let currentUser = "Srija";

// Save data in browser
function saveData() {
    localStorage.setItem("pvBooks", JSON.stringify(books));
    localStorage.setItem("pvRequests", JSON.stringify(requests));
}

function loadData() {
    const savedBooks = localStorage.getItem("pvBooks");
    const savedRequests = localStorage.getItem("pvRequests");

    if (savedBooks) books = JSON.parse(savedBooks);
    if (savedRequests) requests = JSON.parse(savedRequests);
}

// Notification
function notify(message) {
    const box = document.getElementById("notification");
    box.textContent = message;
    box.style.display = "block";

    setTimeout(() => {
        box.style.display = "none";
    }, 3000);
}

// Display books
function displayBooks() {
    const grid = document.getElementById("bookGrid");

    const search = document.getElementById("searchInput")
        .value.toLowerCase();

    const department = document.getElementById("departmentFilter").value;
    const status = document.getElementById("statusFilter").value;

    let filtered = books.filter(book => {
        const matchesSearch =
            book.title.toLowerCase().includes(search) ||
            book.author.toLowerCase().includes(search) ||
            book.course.toLowerCase().includes(search) ||
            book.department.toLowerCase().includes(search);

        const matchesDepartment =
            department === "All" || book.department === department;

        const matchesStatus =
            status === "All" || book.status === status;

        return matchesSearch && matchesDepartment && matchesStatus;
    });

    grid.innerHTML = "";

    if (filtered.length === 0) {
        grid.innerHTML = '<div class="empty">No books found.</div>';
        return;
    }

    filtered.forEach(book => {
        const card = document.createElement("div");
        card.className = "book-card";

        card.innerHTML = `
            <div class="book-cover">📖</div>
            <h3>${book.title}</h3>
            <p>Author: ${book.author}</p>
            <p>Edition: ${book.edition}</p>
            <p>Course: ${book.course}</p>
            <p>Department: ${book.department}</p>
            <p>Condition: ${book.condition}</p>
            <p>Owner: ${book.owner}</p>
            <span class="status ${book.status}">${book.status}</span>
            <button
                ${book.status !== "Available" ||
                  book.owner === currentUser ? "disabled" : ""}
                onclick="requestBook(${book.id})">
                ${book.owner === currentUser
                    ? "Your Book"
                    : book.status === "Available"
                    ? "Request Borrow"
                    : book.status}
            </button>
        `;

        grid.appendChild(card);
    });
}

// Request borrowing
function requestBook(id) {
    const book = books.find(b => b.id === id);

    if (!book || book.status !== "Available") {
        notify("Book is not available.");
        return;
    }

    const borrower = prompt("Enter your name:");

    if (!borrower || !borrower.trim()) return;

    book.status = "Reserved";

    requests.push({
        id: Date.now(),
        bookId: id,
        bookTitle: book.title,
        lender: book.owner,
        borrower: borrower.trim(),
        status: "Pending",
        dueDate: null
    });

    saveData();
    renderAll();

    notify("Borrow request sent successfully!");
}

// List a book
document.getElementById("bookForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const book = {
        id: Date.now(),
        title: document.getElementById("title").value.trim(),
        author: document.getElementById("author").value.trim(),
        edition: document.getElementById("edition").value.trim(),
        course: document.getElementById("course").value.trim().toUpperCase(),
        department: document.getElementById("department").value,
        condition: document.getElementById("condition").value,
        owner: document.getElementById("owner").value.trim(),
        status: "Available"
    };

    books.unshift(book);

    saveData();
    this.reset();
    renderAll();

    notify("Your book has been listed!");
});

// Dashboard
function showDashboard() {
    document.getElementById("dashboard").scrollIntoView({
        behavior: "smooth"
    });
}

// Display exchanges
function displayExchanges() {
    const area = document.getElementById("exchangeList");

    const userRequests = requests.filter(r =>
        r.lender === currentUser || r.borrower === currentUser
    );

    area.innerHTML = "";

    if (userRequests.length === 0) {
        area.innerHTML = '<div class="empty">No exchange requests yet.</div>';
        return;
    }

    userRequests.forEach(r => {
        const div = document.createElement("div");
        div.className = "exchange-item";

        let deadline = "";

        if (r.dueDate && r.status === "Approved") {
            const remaining = Math.ceil(
                (new Date(r.dueDate) - Date.now()) / 86400000
            );

            deadline = remaining < 0
                ? `Overdue by ${Math.abs(remaining)} day(s)`
                : remaining === 0
                ? "Due today"
                : `${remaining} day(s) remaining`;
        }

        div.innerHTML = `
            <div>
                <strong>${r.bookTitle}</strong>
                <p>Borrower: ${r.borrower}</p>
                <p>Status: ${r.status}</p>
                ${deadline ? `<p><strong>Return: ${deadline}</strong></p>` : ""}
            </div>
            <div class="exchange-actions">
                ${r.lender === currentUser && r.status === "Pending"
                    ? `<button onclick="updateRequest(${r.id}, 'Approved')">Approve</button>
                       <button onclick="updateRequest(${r.id}, 'Rejected')">Decline</button>`
                    : ""}

                ${r.borrower === currentUser && r.status === "Approved"
                    ? `<button onclick="updateRequest(${r.id}, 'Returned')">Mark Returned</button>`
                    : ""}
            </div>
        `;

        area.appendChild(div);
    });
}

// Approve, reject or return
function updateRequest(id, newStatus) {
    const request = requests.find(r => r.id === id);

    if (!request) return;

    const book = books.find(b => b.id === request.bookId);

    request.status = newStatus;

    if (newStatus === "Approved") {
        request.dueDate = new Date(
            Date.now() + 7 * 24 * 60 * 60 * 1000
        ).toISOString();

        if (book) book.status = "Borrowed";
        notify("Request approved! Seven-day loan started.");

    } else if (newStatus === "Rejected") {
        if (book) book.status = "Available";
        notify("Request declined.");

    } else if (newStatus === "Returned") {
        if (book) book.status = "Available";
        request.dueDate = null;
        notify("Book returned successfully!");
    }

    saveData();
    renderAll();
}

// My listed books
function displayMyBooks() {
    const area = document.getElementById("myBooks");

    const mine = books.filter(b => b.owner === currentUser);

    if (mine.length === 0) {
        area.innerHTML = '<div class="empty">No books listed by you.</div>';
        return;
    }

    area.innerHTML = mine.map(b => `
        <div class="exchange-item">
            <div>
                <strong>${b.title}</strong>
                <p>${b.course} | ${b.status}</p>
            </div>
        </div>
    `).join("");
}

// Update statistics
function updateStats() {
    document.getElementById("totalBooks").textContent = books.length;

    document.getElementById("availableBooks").textContent =
        books.filter(b => b.status === "Available").length;

    document.getElementById("borrowCount").textContent =
        requests.filter(r => r.status === "Approved").length;

    document.getElementById("requestCount").textContent =
        requests.filter(r => r.status === "Pending").length;
}

function renderAll() {
    displayBooks();
    displayExchanges();
    displayMyBooks();
    updateStats();
}

// Search and filtering
document.getElementById("searchInput")
    .addEventListener("input", displayBooks);

document.getElementById("departmentFilter")
    .addEventListener("change", displayBooks);

document.getElementById("statusFilter")
    .addEventListener("change", displayBooks);

// Initialize
loadData();
renderAll();
